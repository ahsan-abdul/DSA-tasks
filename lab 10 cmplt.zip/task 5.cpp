#include<iostream>
using namespace std;

class Node {
public:
    int data;
    Node* prev;
    Node* next;

    Node(int value) {
        data = value;
        prev = NULL;
        next = NULL;
    }
};
class DoublyLinkedList {
public:

    Node* head;

    DoublyLinkedList() {
        head = NULL;
    }
    void insertBeginning(int value) {
        Node* newNode = new Node(value);
        newNode->next = head;
        if (head != NULL) {
            head->prev = newNode;
        }
        head = newNode;
    }
    Node* insertEndRecursive(Node* temp, int value) {
        if (temp == NULL) {
            Node* newNode = new Node(value);
            return newNode;
        }
        if (temp->next == NULL) {
            Node* newNode = new Node(value);
            temp->next = newNode;
            newNode->prev = temp;
            return temp;
        }
        insertEndRecursive(temp->next, value);
        return temp;
    }
    void insertEnd(int value) {
        head = insertEndRecursive(head, value);
    }
    void insertPosition(Node* temp, int value, int pos) {
        if (pos == 1) {
            Node* newNode = new Node(value);
            newNode->next = temp;
            if (temp != NULL) {
                temp->prev = newNode;
            }
            head = newNode;
            return;
        }
        if (pos == 2 && temp != NULL) {
            Node* newNode = new Node(value);
            newNode->next = temp->next;
            newNode->prev = temp;
            if (temp->next != NULL) {
                temp->next->prev = newNode;
            }
            temp->next = newNode;
            return;
        }
        if (temp == NULL) {
            return;
        }
        insertPosition(temp->next, value, pos - 1);
    }
    void deleteValue(Node* temp, int value) {
        if (temp == NULL) {
            return;
        }
        if (temp->data == value) {
            if (temp->prev != NULL) {
                temp->prev->next = temp->next;
            }
            else {
                head = temp->next;
            }
            if (temp->next != NULL) {
                temp->next->prev = temp->prev;
            }
            delete temp;
            return;
        }
        deleteValue(temp->next, value);
    }
    void deletePosition(Node* temp, int pos) {
        if (temp == NULL) {
            return;
        }
        if (pos == 1) {
            if (temp->prev != NULL) {
                temp->prev->next = temp->next;
            }
            else {
                head = temp->next;
            }
            if (temp->next != NULL) {
                temp->next->prev = temp->prev;
            }
            delete temp;
            return;
        }
        deletePosition(temp->next, pos - 1);
    }
    int search(Node* temp, int value, int pos = 1) {
        if (temp == NULL) {
            return -1;
        }
        if (temp->data == value) {
            return pos;
        }
        return search(temp->next, value, pos + 1);
    }
    void printForward(Node* temp) {
        if (temp == NULL) {
            return;
        }
        cout << temp->data << " ";
        printForward(temp->next);
    }
    void printReverse(Node* temp) {
        if (temp == NULL) {
            return;
        }
        printReverse(temp->next);
        cout << temp->data << " ";
    }
    Node* getTail(Node* temp) {
        if (temp == NULL || temp->next == NULL) {
            return temp;
        }
        return getTail(temp->next);
    }
    bool palindrome(Node* left, Node* right) {
        if (left == NULL || right == NULL) {
            return true;
        }
        if (left == right || right->next == left) {
            return true;
        }
        if (left->data != right->data) {
            return false;
        }
        return palindrome(left->next, right->prev);
    }
};

int main() {
    DoublyLinkedList obj;
    obj.insertBeginning(20);
    obj.insertBeginning(10);
    obj.insertEnd(30);
    obj.insertEnd(40);
    obj.insertPosition(obj.head, 25, 3);
    cout << "Forward: ";
    obj.printForward(obj.head);
    cout << endl;
    cout << "Reverse: ";
    obj.printReverse(obj.head);
    cout << endl;
    cout << "Position of 25: ";
    cout << obj.search(obj.head, 25);
    cout << endl;
    obj.deleteValue(obj.head, 25);
    cout << "After Deletion: ";
    obj.printForward(obj.head);
    cout << endl;
    Node* tail = obj.getTail(obj.head);
    if (obj.palindrome(obj.head, tail)) {
        cout << "Palindrome";
    }
    else {
        cout << "Not Palindrome";
    }
    return 0;
}