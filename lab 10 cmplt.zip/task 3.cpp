#include<iostream>
using namespace std;

int maximum(int arr[], int size) {
   
    if (size == 1) {
        return arr[0];
    }
    int smallMax = maximum(arr, size - 1);

    if (arr[size - 1] > smallMax) {
        return arr[size - 1];
    }
    else {
        return smallMax;
    }
}

int main() {

    int arr[] = { 12, 5, 18, 7, 3 };
    int size = 5;

    cout << "Maximum digit from array is : " << maximum(arr, size);

    return 0;
}