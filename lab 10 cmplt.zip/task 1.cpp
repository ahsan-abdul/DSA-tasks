#include<iostream>
using namespace std;

int sum_array(int arr[], int size) {
	if (size==0)
	{
		return 0;
	}
	return arr[size - 1] + sum_array(arr, size - 1);
}

int main() {
	int size = 5;
	int arr[5] = {1,2,3,4,5};
	cout << "sum of the indexes is : " << sum_array(arr, size);
}